<?php
/**
 * Plugin Name: REST Delete SureDash Settings
 * Plugin URI:  https://github.com/brainstormforce/suredash
 * Description: Plugin to add REST Endpoint to delete SureDash Settings.
 * Author:      Brainstorm Force
 * Author URI:  https://brainstormforce.com
 *
 * @package SureDash
 */

namespace SureDashE2E;

require_once __DIR__ . '/rest-api/namespace.php';
require_once __DIR__ . '/customizer-settings/namespace.php';

REST\bootstrap();
Customizer_Settings\bootstrap();
