<?php
/**
 * Display the SureDash settings in the SureDash footer.
 *
 * @package SureDash
 */

namespace SureDashE2E\Customizer_Settings;

/**
 * Bootstrap the plugin.
 *
 * @return void
 */
function bootstrap() {
	add_action(
		'init',
		static function () {
			if ( is_customize_preview() ) {
				add_action( 'wp_footer', __NAMESPACE__ . '\\dump_plugin_settings' );
			}
		}
	);

	add_action(
		'wp_head',
		static function () {
			echo '<style id="suredash-e2e-custom-css">
				body a {
					text-decoration: underline;
				}
			</style>';
		}
	);
}

/**
 * Dump the SureDash settings in JSON format.
 *
 * @return void
 */
function dump_plugin_settings() {
	$suredash_settings = get_option( SUREDASHBOARD_SETTINGS, array() );

	echo '<pre>';
	echo wp_json_encode( $suredash_settings, JSON_PRETTY_PRINT );
	echo '</pre>';
}
